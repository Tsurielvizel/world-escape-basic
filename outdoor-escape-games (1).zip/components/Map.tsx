import { useEffect, useRef } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

export default function Map({ stations, userLocation, currentStation }) {
  const mapRef = useRef(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      if (!mapRef.current) {
        mapRef.current = L.map("map").setView([31.7683, 35.2137], 13)
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(mapRef.current)
      }

      const map = mapRef.current

      // Clear existing markers
      map.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          map.removeLayer(layer)
        }
      })

      // Add station markers
      stations.forEach((station, index) => {
        const icon = L.divIcon({
          className: "custom-div-icon",
          html: `<div style="background-color: ${index === currentStation ? "#4CAF50" : "#2196F3"}; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; justify-content: center; align-items: center;">${station.id}</div>`,
          iconSize: [30, 30],
          iconAnchor: [15, 15],
        })

        L.marker([station.location.lat, station.location.lng], { icon }).addTo(map)
      })

      // Add user location marker
      if (userLocation) {
        const userIcon = L.divIcon({
          className: "custom-div-icon",
          html: '<div style="background-color: #FF5722; color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; justify-content: center; align-items: center;">You</div>',
          iconSize: [20, 20],
          iconAnchor: [10, 10],
        })

        L.marker([userLocation.lat, userLocation.lng], { icon: userIcon }).addTo(map)
        map.setView([userLocation.lat, userLocation.lng], 15)
      }
    }
  }, [stations, userLocation, currentStation])

  return <div id="map" style={{ width: "100%", height: "100%" }}></div>
}

