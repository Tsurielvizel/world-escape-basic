import Link from "next/link"
import { MapPin, Users, Clock, Brain } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center">
        <Link className="flex items-center justify-center" href="#">
          <MapPin className="h-6 w-6 mr-2" />
          <span className="font-bold">OutdoorEscape</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            How It Works
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Games
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Locations
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Contact
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-black">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-white">
                  Escape the Ordinary, Embrace the Adventure
                </h1>
                <p className="mx-auto max-w-[700px] text-gray-300 md:text-xl">
                  Discover thrilling outdoor escape games that challenge your mind and immerse you in exciting
                  adventures.
                </p>
              </div>
              <div className="space-x-4">
                <Button asChild className="bg-white text-black hover:bg-gray-200">
                  <Link href="/games">Explore Games</Link>
                </Button>
                <Button variant="outline" className="text-white border-white hover:bg-white hover:text-black">
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-12">
              Why Choose OutdoorEscape?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="flex flex-col items-center text-center">
                <MapPin className="h-12 w-12 mb-4 text-blue-600" />
                <h3 className="text-xl font-bold mb-2">Unique Locations</h3>
                <p className="text-gray-600">
                  Explore your city like never before with our carefully chosen game locations.
                </p>
              </div>
              <div className="flex flex-col items-center text-center">
                <Users className="h-12 w-12 mb-4 text-blue-600" />
                <h3 className="text-xl font-bold mb-2">Team Building</h3>
                <p className="text-gray-600">
                  Perfect for friends, family, or corporate events. Strengthen bonds while having fun.
                </p>
              </div>
              <div className="flex flex-col items-center text-center">
                <Clock className="h-12 w-12 mb-4 text-blue-600" />
                <h3 className="text-xl font-bold mb-2">Timed Challenges</h3>
                <p className="text-gray-600">Race against the clock to solve puzzles and complete your mission.</p>
              </div>
              <div className="flex flex-col items-center text-center">
                <Brain className="h-12 w-12 mb-4 text-blue-600" />
                <h3 className="text-xl font-bold mb-2">Mind-Bending Puzzles</h3>
                <p className="text-gray-600">Engage your brain with our creative and challenging puzzles.</p>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-12">Featured Game</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <img
                  src="/placeholder.svg?height=400&width=600"
                  alt="City Secrets Game"
                  className="rounded-lg shadow-lg"
                  width={600}
                  height={400}
                />
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl font-bold">City Secrets</h3>
                <p className="text-gray-600">
                  Uncover the hidden mysteries of your city in this thrilling outdoor escape game. Navigate through
                  historic landmarks, solve cryptic clues, and race against time to unveil the city's best-kept secrets.
                </p>
                <Button asChild>
                  <Link href="/games/city-secrets">Learn More</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-blue-600">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-white">
                  Ready for Your Next Adventure?
                </h2>
                <p className="mx-auto max-w-[600px] text-gray-100 md:text-xl">
                  Book your outdoor escape game now and experience the thrill of solving mysteries in the real world.
                </p>
              </div>
              <Button className="bg-white text-blue-600 hover:bg-gray-200">Book Now</Button>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 OutdoorEscape. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}

