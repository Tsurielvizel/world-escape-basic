"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { MapPin, Users, Clock, ArrowLeft, Compass } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import dynamic from "next/dynamic"

const Map = dynamic(() => import("@/components/Map"), { ssr: false })

const stations = [
  {
    id: 1,
    name: "Western Wall",
    riddle:
      "I stand tall and strong, a remnant of ancient glory. Prayers whispered in my cracks, I hold centuries of story. What am I?",
    answer: "western wall",
    hint: "It's the holiest site in Judaism",
    location: { lat: 31.7767, lng: 35.2345 },
  },
  {
    id: 2,
    name: "Mount of Olives",
    riddle:
      "Ascend me for a view divine, where olive trees have grown through time. Jerusalem's Old City lies below, from here, history's seeds did sow. What am I?",
    answer: "mount of olives",
    hint: "It's a mountain ridge east of Jerusalem's Old City",
    location: { lat: 31.7788, lng: 35.2425 },
  },
]

export default function CitySecretsGame() {
  const [currentStation, setCurrentStation] = useState(0)
  const [userAnswer, setUserAnswer] = useState("")
  const [showHint, setShowHint] = useState(false)
  const [userLocation, setUserLocation] = useState(null)

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.watchPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          })
        },
        (error) => {
          console.error("Error getting location:", error)
        },
      )
    }
  }, [])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (userAnswer.toLowerCase() === stations[currentStation].answer) {
      if (currentStation < stations.length - 1) {
        setCurrentStation(currentStation + 1)
        setUserAnswer("")
        setShowHint(false)
      } else {
        alert("Congratulations! You've completed the game!")
      }
    } else {
      alert("That's not correct. Try again!")
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <ArrowLeft className="h-6 w-6 mr-2" />
          <span className="font-medium">Back to Home</span>
        </Link>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100">
          <div className="container px-4 md:px-6">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl text-center mb-8">
              City Secrets: Jerusalem
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-bold mb-4">
                      Station {currentStation + 1}: {stations[currentStation].name}
                    </h2>
                    <p className="text-lg mb-4">{stations[currentStation].riddle}</p>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <input
                        type="text"
                        value={userAnswer}
                        onChange={(e) => setUserAnswer(e.target.value)}
                        placeholder="Your answer"
                        className="w-full p-2 border rounded"
                      />
                      <Button type="submit" className="w-full">
                        Submit Answer
                      </Button>
                    </form>
                    {!showHint && (
                      <Button variant="outline" onClick={() => setShowHint(true)} className="mt-4 w-full">
                        Get Hint
                      </Button>
                    )}
                    {showHint && <p className="mt-4 text-gray-600">{stations[currentStation].hint}</p>}
                  </CardContent>
                </Card>
              </div>
              <div className="space-y-4">
                <div className="h-[400px] rounded-lg overflow-hidden">
                  <Map stations={stations} userLocation={userLocation} currentStation={currentStation} />
                </div>
                <div className="flex items-center space-x-4 text-gray-600">
                  <MapPin className="h-5 w-5" />
                  <span>Jerusalem, Israel</span>
                </div>
                <div className="flex items-center space-x-4 text-gray-600">
                  <Users className="h-5 w-5" />
                  <span>2-6 players</span>
                </div>
                <div className="flex items-center space-x-4 text-gray-600">
                  <Clock className="h-5 w-5" />
                  <span>60-90 minutes</span>
                </div>
                <div className="flex items-center space-x-4 text-gray-600">
                  <Compass className="h-5 w-5" />
                  <span>GPS-enabled adventure</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">© 2024 OutdoorEscape. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}

