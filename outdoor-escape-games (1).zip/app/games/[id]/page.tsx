"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Game({ params }) {
  const [game, setGame] = useState(null)
  const router = useRouter()

  useEffect(() => {
    const storedGames = JSON.parse(localStorage.getItem("games") || "[]")
    const foundGame = storedGames.find((g) => g.id.toString() === params.id)
    setGame(foundGame)
  }, [params.id])

  const startGame = () => {
    router.push(`/games/${params.id}/station/0`)
  }

  if (!game) return <div>Loading...</div>

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">{game.title}</h1>
      <Card>
        <CardHeader>
          <CardTitle>Game Information</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">{game.description}</p>
          <Button onClick={startGame} className="w-full">
            Start Game
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

