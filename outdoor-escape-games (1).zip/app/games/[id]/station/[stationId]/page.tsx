"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export default function Station({ params }) {
  const [game, setGame] = useState(null)
  const [station, setStation] = useState(null)
  const [userAnswer, setUserAnswer] = useState("")
  const [showHint, setShowHint] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const storedGames = JSON.parse(localStorage.getItem("games") || "[]")
    const foundGame = storedGames.find((g) => g.id.toString() === params.id)
    setGame(foundGame)
    setStation(foundGame.stations[Number.parseInt(params.stationId)])
  }, [params.id, params.stationId])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (userAnswer.toLowerCase() === station.answer.toLowerCase()) {
      if (Number.parseInt(params.stationId) + 1 >= game.stations.length) {
        alert("Congratulations! You've completed the game!")
        router.push(`/games/${params.id}`)
      } else {
        router.push(`/games/${params.id}/station/${Number.parseInt(params.stationId) + 1}`)
      }
    } else {
      alert("Incorrect answer. Try again!")
    }
  }

  if (!game || !station) return <div>Loading...</div>

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">
        {game.title} - Station {Number.parseInt(params.stationId) + 1}
      </h1>
      <Card>
        <CardHeader>
          <CardTitle>{station.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">{station.riddle}</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              type="text"
              placeholder="Your answer"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              required
            />
            <Button type="submit" className="w-full">
              Submit Answer
            </Button>
          </form>
          {!showHint && (
            <Button variant="outline" onClick={() => setShowHint(true)} className="mt-4 w-full">
              Get Hint
            </Button>
          )}
          {showHint && <p className="mt-4 text-gray-600">{station.hint}</p>}
        </CardContent>
      </Card>
    </div>
  )
}

